<?php
$data = file_get_contents('good.txt'); // 要发送的文件
 
$opts = array(
    'http' => array(
        'method' => 'POST',
        'header' => 'content-type:application/x-www-form-urlencoded',
        'content' => $data
    )
);
 
$context = stream_context_create($opts);
 
$url = 'http://localhost/add.php'; // 接收的url
 
file_get_contents($url, false, $context);
echo "success";
 
?>
