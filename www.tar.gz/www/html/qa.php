<?php
$conn = new MongoClient("mongodb://127.0.0.1:27017");
$db = $conn->selectDB('l2');
$coll = $db->selectCollection('first');
// 迭代显示文档标题
$a = '{$coll->find()}';
$b=json_decode($a,true);
var_dump($b['cpu']);
?>
