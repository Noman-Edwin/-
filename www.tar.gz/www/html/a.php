<?php 
  echo "n";
$mongo =  new MongoClient("mongodb://127.0.0.1:27017"); //链接远程数据库 
echo "new";
$curDB = $mongo->selectDB("test");    //选择要操作的数据库，如果不存在，则自动创建 
$collection = $curDB->selectCollection("test"); //选中一个集合（理解为 table），如果不存在，则自动创建 
//$collection->drop();       //清空集合 testCollection 
  
$count = $collection->count();     //查看集合中的数据量 
echo "insert前集合中有[".$count."]条数据<Br>";  //这里的二条数据主命令行下插入的。 
  
echo "<br>********** mongodb php insert 插入 *************<br>"; 
  
$obj = array("title"=>"围城","auther"=>"钱钟书"); 
$rel = $collection->insert($obj); 
var_dump($rel);         //打印插入后的结果是bool型的 
echo "<Br>新增对象的id：".$obj['_id']."<Br>"; 
  
$obj = array("title"=>"朝发白帝城","auther"=>"李白"); 
$rel = $collection->insert($obj,array('safe'=>true)); //safe 表示是否返回操作结果信息，返回的信息为 array 
print_r($rel);         //插入后的结果是数组 
echo "<Br>新增对象的id：".$obj['_id']."<Br>";; 
  
$count = $collection->count();     //查看集合中的数据量 
echo "insert后集合中有[".$count."]条数据<Br>"; 
  
?> 
