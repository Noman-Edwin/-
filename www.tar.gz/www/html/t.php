
<?php

    $conn = new MongoClient("mongodb://127.0.0.1:27017");
    $db = $conn->selectDB('test');
    $coll = $db->selectCollection('one');
    $coll->insert(array('a' => 1));
