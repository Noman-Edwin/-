<?php
echo "sucess add";
$conn = new MongoClient("mongodb://127.0.0.1:27017");
echo "sucess 1";
$db = $conn->selectDB('l2');
echo "sucess 2";
$coll = $db->selectCollection('one');
echo "sucess 3";
$tmpfile = 'tmp.txt'; // 临时文件，用于保存接收到的文件流
 
$content = $GLOBALS['HTTP_RAW_POST_DATA'];
if(empty($content)){  
    $content = file_get_contents('php://input');
}
 
file_put_contents($tmpfile, $content, true);  
 
$file = file_get_contents($tmpfile);

$b=json_decode('$file',true);
$coll->insert($b);
echo "sucess add"
 
?>
