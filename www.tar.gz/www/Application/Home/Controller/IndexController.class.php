<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function post(){
        echo 'post';
    }

    public function get(){
        echo 'get';
    }
                        
}
