<?php
	$conn = new MongoClient("mongodb://localhost:27017");
echo "1dsad";
	$db = $conn->selectDB('health');
echo "2dsad";
	$coll = $db->selectCollection('urls');
       echo "3dsad";
?>
