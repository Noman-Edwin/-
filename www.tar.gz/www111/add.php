<?php

 
$tmpfile = 'tmp.txt'; // 临时文件，用于保存接收到的文件流
 
$content = $GLOBALS['HTTP_RAW_POST_DATA'];
if(empty($content)){  
    $content = file_get_contents('php://input');
}
 
file_put_contents($tmpfile, $content, true);  
 
$file = file_get_contents($tmpfile);

$b=json_decode('$file',true);
l$conn = new MongoClient("mongodb://127.0.0.1:27017");
$db = $conn->selectDB('l2');
$coll = $db->selectCollection('first');
$coll->insert($b);
 
?>
