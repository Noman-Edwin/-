
<?php

$client = new MongoDB\Client("mongodb://localhost:27017");
$collection = $client->demo->beers;
echo "hello";

$result = $collection->insertOne( [ 'name' => 'Hinterland', 'brewery' => 'BrewDog' ] );

echo "Inserted with Object ID '{$result->getInsertedId()}'";
?>

