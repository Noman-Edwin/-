<?php
require "conn.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title>demo</title>
 </head>
  
 <body>
  
 <?php
    $sqlstr = "select * from student order by id";
    $query = mysql_query($sqlstr) or die(mysql_error());
    $result = array();
    while($thread=mysql_fetch_assoc($query)){
        $result[] = $thread;
    }
  
    if($result){
        echo '<table>';
        echo '<th>NO</th><th>学生id</th><th>学生名字</th><th>学生邮箱</th><th>学生地址</th>';
        foreach($result as $row){
            echo '<tr>';
            echo '<td>'.$row['id'].'</td>';
            echo '<td>'.$row['xid'].'</td>';
            echo '<td>'.$row['name'].'</td>';
            echo '<td>'.$row['email'].'</td>';
            echo '<td>'.$row['address'].'</td>';
            echo '</tr>';
        }
        echo '</table>';
    }
  
 ?>
    
 </body>
</html>
